package com.jbk;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Scanner;

public class SqlCommands {
	
	static long balance=0;
	public static String Name=null;
	public static int pass=0;
	public static String acc_no=null;
	public static String mob_no=null;
	
	
	public static void main(String[]args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		Methods ac=new Methods();
		Methods M=new Methods();  //Pin Generator
		Random r1=new Random();
		Random r2=new Random();
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection cm = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","root");
		Statement st = cm.createStatement();
		PreparedStatement p=null;
		
		System.out.println("\n*****************************************************************\n");
		System.out.println("\n       <<***WELCOME***>>>       \n\nHope you doing greate\n\n"
		                    +"\t\tMake your choice >>\n\n1]Account Verification \n2]Bank transaction");
		int x12=0;
		try 
		 {
			x12=sc.nextInt();
			if(x12>5)
			{
				System.out.println("Invalid Option !");
			}
		 }
		catch(Exception e)
		 {
			 System.out.println("Invalid Option");
		 }
		
		switch(x12)
		{
		case 1:
			for(int i=0;i<2;i++)
			{
			System.out.println("\n**********************************************************\n");
			System.out.println("Choose Your Option >>\n"
					+"1]Bank Account Opening Form\n2]Passbook\n3]Delete Current Bank Account\n4]Exit");
			int choose=0;
			try
			 {
				choose=sc.nextInt();
				if(choose>6)
				{
					System.out.println("Invalid Option\nChoose Again");
					choose=sc.nextInt();
					if(choose>6)
					{
						System.out.println("Again Invalid Option \nTry after a second");
						System.exit(choose);
					}
				}
			 }
			catch(Exception e)
			 {
			 	System.out.println("Invalid Option");
		     }
			switch(choose)
			 {
			case 1:
				int a=r1.nextInt(500);
				int b=r1.nextInt(500);
				int c=r1.nextInt(500);
				int d=r1.nextInt(500);
				int e=r1.nextInt(500);
				int number=a+b+c+d+e;
				
				int x=r2.nextInt(500);
				int y=r2.nextInt(500);
				int z=r2.nextInt(500);
				int l=r2.nextInt(500);
				int m=r2.nextInt(500);
				int number2=x+y+z+l+m;
				
				if(number>1000)
				 {
					pass=number;
				 }
				if(number2>1000)
				 {
					pass=number2;
				 }
				//Account Number Generator
				int a1=r1.nextInt(50000000);
				int b1=r1.nextInt(50000000);
				int c1=r1.nextInt(50000000);
				int d1=r1.nextInt(50000000);
				int e1=r1.nextInt(50000000);
				
				int x1=r1.nextInt(50000000);
				int y1=r1.nextInt(50000000);
				int z1=r1.nextInt(50000000);
				int l1=r1.nextInt(50000000);
				int m1=r1.nextInt(50000000);
				
				long a11=a1+b1+c1+d1+e1;
				long a12=x1+y1+z1+l1+m1;
				long j1=a11+a12;
				String acc1=Long.toString(j1);
				int lg=acc1.length();
				acc_no=acc1;
				
				M.addingData();
				String query="insert into bank_customer values('"+Name+"',"+acc_no+","+mob_no+","+balance+","+pass+")";
				int k=st.executeUpdate(query);
				System.out.println(k+"-Your Bank Account Created ");
				System.out.println("Your Account Number and Pin is generated\n"+"Pin>>"+pass+"\nAccount Number>>"+acc_no);
				
				System.out.println("\n**********************************************************\n");
				break;
			case 2:
				System.out.println("Enter Pin >>");
				int pin=sc.nextInt();
				String sql="select * from bank_customer where pass="+pin;
				p=cm.prepareStatement(sql);
				ResultSet rs=p.executeQuery();
				//condition check
				while(rs.next())
				{
					String name=rs.getString("name");
					long mob=rs.getLong("mob_no");
					long acc=rs.getLong("acc_no");
					int balance=rs.getInt("balance");
					
					System.out.println("\n**********************************************************\n");
					System.out.println("\t\t*****WELCOME******\n\nCustomer Name>>"+name+"\n"+"Account Number>>"+acc+"\n"+"Mobile Number>>"+mob+"\n"+"Current Balance>>"+balance);
					System.out.println("Thanks For Visiting Mr."+name);
				}
				System.out.println("\t");
				break;
			case 3:
				System.out.println("Enter Your Account Number>>");
				acc_no=sc.next();
				int k1=st.executeUpdate("delete from bank_customer where acc_no="+acc_no);
				System.out.println(k1+" Account Deleted !");
				break;
			case 4:
				System.out.println("Exiting");
				System.out.println("******All Process Done******");
				break;
			case 5:
				try
				{
					String sql1="select * from bank_customer";
					p=cm.prepareStatement(sql1);
					ResultSet rs1=p.executeQuery();
					System.out.println("Pin\t\tName\t\tMobile\t\tAccount No\t\tBalance");
					while(rs1.next())
					{
						int password=rs1.getInt("pass");
						String name=rs1.getString("name");
						long mob=rs1.getLong("mob_no");
						long acc=rs1.getLong("Acc_no");
						int balance=rs1.getInt("balance");
						
						System.out.println(password +"\t\t" +name +"\t\t"+mob +"\t\t"+acc +"\t\t"+ balance);
					}
				}
				catch(SQLException h)
				{
					System.out.println(h);
				}
				System.out.println("\n\n^^Data");
				break;
			 }
		  }
		case 2:
			System.out.println("\n\n********** ATM Machine **********\n");
			System.out.println("If their is no correct PIN message comes then PIN is wrong!");
			System.out.println("Enter PIN>>");
			int pin=sc.nextInt();
			String sql="select * from bank_customer where pass="+pin;
			p=cm.prepareStatement(sql);
			ResultSet rs=p.executeQuery();
			
			String sql1="select * from bank_customer where pass="+pin;
			p=cm.prepareStatement(sql1);
			ResultSet rs1=p.executeQuery();
			while(rs1.next())
			{
				int password=rs1.getInt("pass");
				String name=rs1.getString("name");
				long mob=rs1.getLong("mob_no");
				long acc=rs1.getLong("Acc_no");
				int balance=rs1.getInt("balance");
				
				System.out.println(password);
				if(pin!=password)
				{
					System.out.println("Incorrect Password");
				}
				else if(pin==password)
				{
					System.out.println("Correct PIN Good to go>>");
					break;
				}	
			}
			System.out.println("\nEnter the option>>\n");
			System.out.println("1-Deposite        2-Withdraw");
			System.out.println("3-Mini Statement      4-Show Balance");
			int option=0;
			try
			{
				option=sc.nextInt();
			}
			catch(IllegalArgumentException e)
			{
				System.out.println("Invalid option");
			}
			for(int i=0;i<2;i++)
			{
				switch(option)
				{
				case 1:
					while(rs.next())
					{
						String name=rs.getString("name");
						long mob=rs.getLong("mob_no");
						long acc=rs.getLong("acc_no");
						int balance=rs.getInt("balance");
						System.out.println("balance>"+balance);
						System.out.println("Enter the amount for Deposite>>");
						int add=sc.nextInt();
						if(add<1)
						{
							System.out.println("Invalid Amount!\nTry Again");
						}
						else if(add>1000000)
						{
							System.out.println("You cant deposite that much money !");
						}
						else
						{
							balance+=add;
							System.out.println();
						}
						sql="update bank_customer set balance="+balance+"where pass="+pin;
						int k=st.executeUpdate(sql);
						System.out.println("Current Balance>>"+balance);
					}
					break;
				case 2:
					while(rs.next())
					{
						String name=rs.getString("name");
						long mob=rs.getLong("mob_no");
						long acc=rs.getLong("acc_no");
						int balance=rs.getInt("balance");
						System.out.println("balance>"+balance);
						System.out.println("balance>"+balance);
						System.out.println("Enter the amount for Withdraw>>");
						int minus=sc.nextInt();
						int tot=0;
						if(balance<minus)
						{
							System.out.println("Bank balance is low can't withdraw");
						}
						else if(minus==balance)
						{
							System.out.println("You can't withdraw all amount from bank!");
						}
						else if(minus>1000000)
						{
							System.out.println("You can't withdraw that to much money!");
						}
						else if(minus<1)
						{
							System.out.println("Low Number!\nTry Again");
						}
						else
						{
							balance-=minus;
						}
						System.out.println("Current balance >>"+balance);
					}
					sql="update bank_customer set balance="+balance+"where pass="+pin;
					int k=st.executeUpdate(sql);
					break;
				case 3:
					try
					{
						while(rs.next())
						{
							String name=rs.getString("name");
							long mob=rs.getLong("mob_no");
							long acc=rs.getLong("acc_no");
							int balance=rs.getInt("balance");
							
							System.out.println("\n***************************************************************\n");
							System.out.println("Mini Statement");
							System.out.println("Name>>"+name+"\nMob No"+mob+"\nBalance"+balance);
						}
					}
					catch(SQLException f)
					{
						System.out.println(f);
					}
					break;
				case 4:
					while(rs.next())
					{
						String name=rs.getString("name");
						long mob=rs.getLong("mob_no");
						long acc=rs.getLong("acc_no");
						int balance=rs.getInt("balance");
						System.out.println("Current Balance>>"+balance);
					}
					break;
				}
				
			}
			System.out.println("|n***************************************************************\n");
			System.out.println("\n"+"Thank You for visiting us");
	    }
		
	}
}
